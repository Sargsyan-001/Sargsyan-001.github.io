import React from 'react'
import "./footer.css"
export default function Footer() {
  return (
    <>
      <footer className='footer-box'>
        <p>© 2020 Composet . All rights reserved.</p>
      </footer>
    </>
  )
}
